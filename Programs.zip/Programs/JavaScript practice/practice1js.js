function loan()
{
	
	var	cusname=document.loanform.name.value;
	var cusmob=document.loanform.mob.value;
	var cusmail=document.loanform.mail.value;
    alert("CustomerName:"+cusname+"\nCustomerMobile:"+cusmob+"\nCstomerMail:"+cusmail);
}