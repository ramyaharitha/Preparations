function check()
{
	
	var tidno=document.regform.idno.value;
	var tscore=document.regform.rascore.value;
	var tname=document.regform.name.value;
	var tmob=document.regform.mob.value;
	alert("TraineeId:"+tidno+"\nTrainee Score:"+tscore+"\nTrainee Name:"+tname+"\nTrainee mobile:"+tmob);
}