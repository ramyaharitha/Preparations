select substr(last_name, 1,8) as last_name , lpad('*',salary/1000,'*')as salary from employees order by salary desc
/
