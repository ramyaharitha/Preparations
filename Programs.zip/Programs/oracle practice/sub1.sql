select last_name, hire_date from employees where employee_id<>(select employee_id from employees where last_name='Zlotkey')
/
