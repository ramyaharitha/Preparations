select salary from employees where department_id=60
/
