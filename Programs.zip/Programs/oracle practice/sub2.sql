select last_name, employee_id, salary from employees where salary>(select avg(salary) from employees)
/
