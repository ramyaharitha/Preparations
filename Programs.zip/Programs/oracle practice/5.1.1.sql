create table employee as select * from emp where 1=3
/
