select location_id,street_address,city,state_province,country_name from locations natural join countries
/
