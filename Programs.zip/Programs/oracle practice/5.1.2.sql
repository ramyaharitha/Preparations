insert into employee
select * from emp
/
