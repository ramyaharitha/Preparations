select salary from employees where salary>any(select department_id from departments where department_id=60)
/
