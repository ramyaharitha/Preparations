select count(distinct manager_id) from employees
/
