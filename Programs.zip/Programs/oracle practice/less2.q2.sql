select employee_id,last_name,salary,round(salary*(15.5/100)) as "New Salary" from employees 
/
