select last_name,employee_id from employees where department_id in(select department_id from employees where last_name like '%u%')
/
