select e1.last_name emp,e2.last_name mgr from
employees e1 join employees e2
on ( e1.manager_id=e2.employee_id
)
/
