select employee_id,last_name,salary,salary*(15.5/100) as "New Salary", salary*(15.5/100) - salary increase  from employees 
/
