select last_name ||' earns '||to_char(salary,'$99,999.00')||' monthly but wants '||to_char(salary*3,'$99,99999.00') from employees
/
