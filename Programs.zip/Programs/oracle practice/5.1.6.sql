insert into employee values(&empno,'&ename','&ejob','&mgr','&hiredate',&sal,&comm,&deptno)
/
