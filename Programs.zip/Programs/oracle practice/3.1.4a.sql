insert into book_transactions values(10000007,1019,100008,'10-jul-2018','20-jul-2018','23-jul-2018')
/
