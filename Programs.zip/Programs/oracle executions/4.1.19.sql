alter table accountmaster
add constraint balance_check check(ledgerbalance>5000)
/
