select next_day (last_day(sysdate)-7,'Friday') from dual
/
