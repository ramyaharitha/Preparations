select student_name,to_char(student_dob,'fmMonth,DD YYYY')
FROM student_master
where to_char(student_dob,'Dy') in('Sat','Sun')
/
