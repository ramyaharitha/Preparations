alter table cust_table
add e_mail varchar2(10)
/
