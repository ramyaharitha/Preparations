alter table Cust_Table add constraint Custid_Prim primary key(CustomerId)
/
