alter table cust_table enable constraint custid_prim
/
