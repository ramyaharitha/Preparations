select s.staff_code,s.staff_name,d.dept_name,dm.design_name from staff_master s,department_master d,designation_master dm
where d.dept_code=s.dept_code and dm.design_code=s.design_code and s.hiredate between sysdate and (sysdate-30)
/
