select * from synemp
/
