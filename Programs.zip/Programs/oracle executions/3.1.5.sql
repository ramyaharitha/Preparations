select s.staff_code,s.staff_name,dm.design_name,s.dept_code ,b.book_code,b.book_name,b.book_pub_author,
(5*(sysdate-t.book_expected_return_date)) "fine" from staff_master s,book_master b, book_transactions t, designation_master dm
where s.staff_code=t.staff_code and b.book_code=t.book_code and dm.design_code=s.design_code
/
