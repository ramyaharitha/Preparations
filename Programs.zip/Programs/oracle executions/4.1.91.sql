alter table cust_table disable constraint custid_prim
/
