select staff_name,hiredate,to_char(hiredate,'DAY')day,to_char(hiredate,'D') from staff_master
order by to_char(hiredate-1,'d')
/
