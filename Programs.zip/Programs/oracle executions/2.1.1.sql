select staff_name,lpad(staff_sal,15,'$')
from staff_master
/
