alter table customer modify Cust_Name varchar2(30) not null
/
