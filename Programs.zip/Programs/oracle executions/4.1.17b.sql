insert into customer_master1 values(1001, 'George', '#116 France', '#116 France', 'M', 25, 434524)
/
