select staff_name,round((sysdate-hiredate)/12) "months worked" from staff_master
order by round((sysdate-hiredate)/12)
/
