alter table customer add (Gender Varchar2(1),Age	Number(3),PhoneNo Number(10))
/
