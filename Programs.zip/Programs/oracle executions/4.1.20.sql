drop table customer_master1 cascade constraints
/
