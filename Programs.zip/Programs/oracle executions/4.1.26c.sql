insert into departmentmaster values(seq_dept.NEXTVAL,'MARKETING','NOIDA')
/
