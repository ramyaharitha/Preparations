create SYNONYM synemp for emp
/
