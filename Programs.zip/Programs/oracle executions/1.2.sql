select staff_code,staff_name,dept_code from staff_master
where sysdate-hiredate>=18
order by sysdate-hiredate
/
