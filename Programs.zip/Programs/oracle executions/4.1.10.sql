 truncate table cust_table
/
