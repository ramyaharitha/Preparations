select book_name,book_pub_author
from book_master
where book_pub_author like
(select book_pub_author from book_master
group by book_pub_author
having count(book_code)>1)
/
