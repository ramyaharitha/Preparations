select student_code,student_name, decode('&dept_code',20,'Electricals',30,'others') "DEPT_NAME" from student_master
/
