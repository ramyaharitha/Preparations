select round(max(staff_sal)) maximum, round(min(staff_sal)) minimum, round(sum(staff_sal)) total, round(avg(staff_sal)) average from staff_master group by dept_code
/
