select dept_code,sum(staff_sal) from staff_master where mgr_code is null  group by dept_code having sum(staff_sal)>20000
/
