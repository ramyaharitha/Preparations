      insert into cust_table values(1003, 'Nanapatekar',' #115 India', '#115 India ', 'M', 45, 431525)
/
