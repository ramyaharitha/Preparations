alter table cust_table
drop column e_mail
/
