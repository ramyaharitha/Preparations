 create view acsvw10 as (select * from accountmaster)with read only
/
