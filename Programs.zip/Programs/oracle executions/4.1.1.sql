create table customer (CustomerId	Number(5),Cust_Name varchar2(20) , Address1 varchar2(30), Addresss2 varchar2(30) )
/
