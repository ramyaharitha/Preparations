create table departmentmaster(deptno number(30),Dname varchar2(25),location varchar2(25))
/
