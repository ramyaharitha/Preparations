 DROP sequence seq_dept
/
