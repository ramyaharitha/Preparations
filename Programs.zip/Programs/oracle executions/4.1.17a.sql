insert into customer_master1 values(1000, 'Allen', '#115 Chicago', '#115 Chicago', 'M', 25, 7878776)
/
