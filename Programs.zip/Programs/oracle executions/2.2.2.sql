select dept_code,count(mgr_code) "total number of managers" from staff_master group by dept_code
/
