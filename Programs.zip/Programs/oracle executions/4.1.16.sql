alter table accountmaster
add constraints cust_acc foreign key (customerid) references customer_master1(customerid)
/
