select s.staff_name,count(*) "TOTAL STRENGTH"
from staff_master s,staff_master m where s.staff_code=m.mgr_code
group by s.staff_name
/
