create table customer_master1 (CUSTOMERID NUMBER(5),CustomerName varchar2(30) not null,Address1 Varchar2(30) not null,Address2 Varchar2(30),gender varchar2(2),age number(3),phoneno number(10),constraint custid_pk primary key(customerid))
/
