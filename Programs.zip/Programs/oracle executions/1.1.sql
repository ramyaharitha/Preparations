select staff_name,design_code from staff_master
where hiredate<to_date('01-jan-2003')
and staff_sal between 12000 and 25000
/
