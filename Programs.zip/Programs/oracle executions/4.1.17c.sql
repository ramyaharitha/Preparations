insert into customer_master1 values(1002, 'Becker', '#114 New York', '#114 New York', 'M', 45, 431525)
/
