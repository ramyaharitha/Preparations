create table accountmaster (customerid number(5),accountnumber number(10,2),accounttype char(3),ledgerbalance number(10,2) not null,constraint acc_pk primary key(accountnumber))
/
