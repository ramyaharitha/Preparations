select s.staff_code Staff#, s.staff_name Staff, s.mgr_code,m.staff_name,d.dept_name from staff_master s join staff_master m on (s.mgr_code=m.staff_code) join department_master d on d.dept_code=s.dept_code
/
