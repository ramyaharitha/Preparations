alter table customer rename column Cust_Name to CustomerName
/
