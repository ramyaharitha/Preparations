select staff_name from staff_master
where staff_name like '%_%'
/
