create index no_name on emp(empno)
/
