create view vAccs_Dtls AS select accounttype, ledgerbalance from Accountmaster where accounttype = 'IND' and ledgerbalance>10000 with check option
/
