insert into Cust_Table values(1002,'Becker','#114 New York','#114 New York','M',45,431525)
/
