select s.staff_code,s.staff_name,d.dept_name
from staff_master s,department_master d,book_transactions bt
where s.staff_code=bt.staff_code
and d.dept_code=s.dept_code
group by s.staff_code,s.staff_name,d.dept_name
having count(bt.book_code)>1
/
