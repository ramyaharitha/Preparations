select b.book_code,initcap(b.book_name),b.book_pub_author,
b.book_pub_year from book_master b,book_transactions t
where b.book_code=t.book_code and t.book_actual_return_date is null
and t.book_expected_return_date=(select next_day(sysdate,'MONDAY')-interval '7' day from dual)
/
