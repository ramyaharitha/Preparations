create table accountdetails as (select * from accountmaster)
/
