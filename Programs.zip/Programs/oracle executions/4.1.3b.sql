rename customer to "Cust_Table"
/
