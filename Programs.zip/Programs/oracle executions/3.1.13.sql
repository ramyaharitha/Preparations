select s.dept_code "department code",d.dept_name "department name",
count(*) "number of people" from department_master d,staff_master s
where  s.dept_code=d.dept_code group by s.dept_code,d.dept_name
/
