select s.student_code,s.student_name,b.book_code,b.book_name from student_master s join book_transactions t on s.student_code=t.student_code join book_master b on b.book_code=t.book_code where t.book_expected_return_date=sysdate
/
