create table suppliers(suppid number(5),sname varchar2(30),addr1 varchar2(30),addr2 varchar2(30),contactno number(10))
/
