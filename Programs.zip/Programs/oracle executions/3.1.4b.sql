select staff_name,s.staff_code,dept_name,design_name,b.book_code,book_name,book_issue_date
from staff_master s,book_master b,book_transactions b1,department_master d,designation_master d1
where s.staff_code=b1.staff_code and b1.book_code=b.book_code and s.dept_code=d.dept_code and s.design_code=d1.design_code
and sysdate-book_issue_date<=30
/
